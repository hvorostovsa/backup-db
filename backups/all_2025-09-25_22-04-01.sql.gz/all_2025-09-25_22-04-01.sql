--
-- PostgreSQL database cluster dump
--

\restrict 9BXNAtVI1wgWeaVuBBb7S0LpxgoB3RjH4ipCWYaAUeJhDvZtbNE6Q1Ovpzb7e26

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE admin;
ALTER ROLE admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:zhdFqm5AoakJx8vT/qVlRA==$YJMSkXreEKtxF0kxNMMFw5DjFkJ+vg9CILTwuoSekjA=:RQPBc6qVxQUoJ1JFyrE5WhNkj2TUMOf6NX9aG+KFoQ0=';

--
-- User Configurations
--








\unrestrict 9BXNAtVI1wgWeaVuBBb7S0LpxgoB3RjH4ipCWYaAUeJhDvZtbNE6Q1Ovpzb7e26

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict PpQ8dL70OypYqfTCXMJmEsAeY6N1FWjIdJGonYda7T5Q9LK1L8M4Cty4tFDNsM1

-- Dumped from database version 17.6 (Debian 17.6-1.pgdg13+1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict PpQ8dL70OypYqfTCXMJmEsAeY6N1FWjIdJGonYda7T5Q9LK1L8M4Cty4tFDNsM1

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict LEUioYcsu7DJSAj3iLlxglOzeLXpqdeDAlhHiOcZEeZ7PlybbwrNuWeAb4Lpsuf

-- Dumped from database version 17.6 (Debian 17.6-1.pgdg13+1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict LEUioYcsu7DJSAj3iLlxglOzeLXpqdeDAlhHiOcZEeZ7PlybbwrNuWeAb4Lpsuf

--
-- Database "test_db" dump
--

--
-- PostgreSQL database dump
--

\restrict dqzSFUyqZHN4Xnr7exhly4fluWifkyTJTRFMwbIvpxHzuajojzAp4Nmd8C748tq

-- Dumped from database version 17.6 (Debian 17.6-1.pgdg13+1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: test_db; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE test_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE test_db OWNER TO admin;

\unrestrict dqzSFUyqZHN4Xnr7exhly4fluWifkyTJTRFMwbIvpxHzuajojzAp4Nmd8C748tq
\connect test_db
\restrict dqzSFUyqZHN4Xnr7exhly4fluWifkyTJTRFMwbIvpxHzuajojzAp4Nmd8C748tq

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    name text,
    "position" text,
    salary integer
);


ALTER TABLE public.employees OWNER TO admin;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO admin;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.employees (id, name, "position", salary) FROM stdin;
1	Иван	Инженер	100000
\.


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.employees_id_seq', 1, true);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict dqzSFUyqZHN4Xnr7exhly4fluWifkyTJTRFMwbIvpxHzuajojzAp4Nmd8C748tq

--
-- PostgreSQL database cluster dump complete
--

